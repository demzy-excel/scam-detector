from flask import Flask, render_template, request
from scam_checker import check_scam

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/check', methods=['POST'])
def check():
    input_data = request.form['input_data']
    result = check_scam(input_data)
    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
