# Scam Detector App

This app checks input text or wallet addresses for signs of scams. Built with Flask.
