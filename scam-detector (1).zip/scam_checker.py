import re

def check_scam(data):
    # Very simple check for now, can be expanded
    scam_keywords = ['airdrop', 'giveaway', 'urgent', 'investment', 'double your money']
    for keyword in scam_keywords:
        if keyword in data.lower():
            return "Warning: This may be a scam."
    if re.search(r'(0x)?[a-fA-F0-9]{40}', data):
        return "Warning: This looks like a suspicious wallet address."
    return "No scam detected."
