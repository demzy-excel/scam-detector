import re

def check_scam(link):
    scam_keywords = ['free', 'airdrop', 'bonus', 'investment', 'crypto', 'doubler']
    if any(keyword in link.lower() for keyword in scam_keywords):
        return "Suspicious or Scam Link!"
    elif not re.match(r'^https?:\/\/', link):
        return "Invalid Link Format!"
    else:
        return "Likely Safe"
