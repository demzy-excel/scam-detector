from flask import Flask, request, render_template
from scam_checker import check_scam

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    result = ''
    if request.method == 'POST':
        link = request.form['link']
        result = check_scam(link)
    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
